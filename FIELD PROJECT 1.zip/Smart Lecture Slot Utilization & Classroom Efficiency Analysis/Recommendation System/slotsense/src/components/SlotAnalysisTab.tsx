import React, { useState } from 'react';
import { 
  Clock, 
  ChevronDown, 
  ChevronUp, 
  HelpCircle,
  BarChart3,
  Flame,
  BatteryMedium,
  Timer,
  CheckCircle2,
  Check
} from 'lucide-react';
import { slotSenseData } from '../utils/recommendationEngine';

interface SlotAnalysisTabProps {
  initialSlot?: string;
}

export const SlotAnalysisTab: React.FC<SlotAnalysisTabProps> = ({ initialSlot }) => {
  const { all_time_slots, slot_scores } = slotSenseData;
  const [expandedSlot, setExpandedSlot] = useState<string | null>(initialSlot || '1:00-1:40');
  const [showFormulas, setShowFormulas] = useState<boolean>(false);

  const getStatus = (score: number) => {
    if (score >= 60) return { label: 'Good', bg: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    if (score >= 50) return { label: 'Needs Review', bg: 'bg-amber-50 text-amber-700 border-amber-200' };
    return { label: 'Low', bg: 'bg-rose-50 text-rose-700 border-rose-200' };
  };

  const getSlotDiagnosis = (slot: string) => {
    switch (slot) {
      case '1:00-1:40':
        return 'Peak student preference window (79 votes) with 73.5% attendance.';
      case '1:40-2:20':
        return 'Highest attendance window (81.7%) with solid concentration retention.';
      case '2:20-3:00':
        return 'Post-lunch attendance slump (64.1%), dropping score below 60.0.';
      case '3:30-4:10':
        return 'Strong post-recess attendance (81.9%), but low student preference (17 votes).';
      case '4:10-4:50':
        return 'Afternoon fatigue onset with sharp decline in student preference (9 votes).';
      case '4:50-5:30':
        return 'Lowest overall score. Low attendance (64.3%) and minimal preference (4 votes).';
      case '5:30-6:10':
        return 'Zero student preference responses. High schedule fatigue.';
      case '6:10-6:50':
        return 'Lowest attendance of the day (63.1%) driven by commuter departures.';
      default:
        return '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Lecture Slot Scoring
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Empirical efficiency ratings across 8 daily time slots. Threshold: 60.0 points.
          </p>
        </div>

        <button
          onClick={() => setShowFormulas(!showFormulas)}
          className="inline-flex items-center px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 transition-colors w-fit"
        >
          <HelpCircle className="w-3.5 h-3.5 mr-1.5 text-slate-400" />
          {showFormulas ? 'Hide Formula Guide' : 'Formula Guide'}
        </button>
      </div>

      {/* Collapsible Formula Guide */}
      {showFormulas && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs transition-all">
          <div className="text-xs font-bold text-slate-900 mb-3 flex items-center">
            <HelpCircle className="w-4 h-4 mr-1.5 text-indigo-600" />
            5-Component Scoring Rules (Total: 100 pts)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <div className="font-bold text-slate-900">Attendance (40 pts)</div>
              <div className="text-[11px] text-slate-500 mt-1">
                ≥85% → 40<br />
                75–84% → 32<br />
                65–74% → 24<br />
                50–64% → 16<br />
                &lt;50% → 8
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <div className="font-bold text-slate-900">Preference (25 pts)</div>
              <div className="text-[11px] text-slate-500 mt-1">
                (Votes / 79 max) × 25<br />
                Direct student timing comfort ratio from 200 survey responses.
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <div className="font-bold text-slate-900">Concentration (15 pts)</div>
              <div className="text-[11px] text-slate-500 mt-1">
                (1 - 0.4925 fatigue) × 15<br />
                = <strong>7.61 pts</strong><br />
                Survey weighted fatigue.
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <div className="font-bold text-slate-900">Schedule (10 pts)</div>
              <div className="text-[11px] text-slate-500 mt-1">
                Continuous: 1.71/5<br />
                Gaps: 3.39/5<br />
                = <strong>5.10 pts</strong>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
              <div className="font-bold text-slate-900">On-Time (10 pts)</div>
              <div className="text-[11px] text-slate-500 mt-1">
                Start: 4.03/5<br />
                End: 4.03/5<br />
                = <strong>8.06 pts</strong> (80.6%)
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Visual Slot Score Cards */}
      <div className="grid grid-cols-1 gap-3">
        {all_time_slots.map(ts => {
          const s = slot_scores[ts];
          const status = getStatus(s.Total_Score);
          const isExpanded = expandedSlot === ts;
          const scorePercent = Math.min(Math.max(s.Total_Score, 0), 100);

          return (
            <div
              key={ts}
              className="bg-white border border-slate-200/80 rounded-2xl p-4 sm:p-5 shadow-xs transition-all hover:border-slate-300"
            >
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                {/* Left: Slot & Timing */}
                <div className="flex items-center space-x-3 sm:w-1/4">
                  <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-mono font-bold text-slate-900 text-sm">{ts}</div>
                    <div className="text-[11px] text-slate-400">
                      {s.Preference_Responses} votes • {s.Average_Attendance}% att
                    </div>
                  </div>
                </div>

                {/* Center: Visual Progress Bar */}
                <div className="flex-1 sm:px-4">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-[11px] text-slate-400">Score Progress</span>
                    <span className="font-mono font-bold text-slate-900 text-sm">
                      {s.Total_Score} <span className="text-slate-400 text-xs font-normal">/ 100</span>
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden relative">
                    {/* Threshold marker at 60% */}
                    <div 
                      className="absolute top-0 bottom-0 w-0.5 bg-slate-400 z-10" 
                      style={{ left: '60%' }} 
                      title="60 pt threshold"
                    />
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        s.Total_Score >= 60 ? 'bg-emerald-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${scorePercent}%` }}
                    />
                  </div>
                </div>

                {/* Right: Status & Collapsible Trigger */}
                <div className="flex items-center justify-between sm:justify-end space-x-3 sm:w-1/4">
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${status.bg}`}>
                    {status.label}
                  </span>

                  <button
                    onClick={() => setExpandedSlot(isExpanded ? null : ts)}
                    className="inline-flex items-center px-2.5 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
                  >
                    <span>Why?</span>
                    {isExpanded ? (
                      <ChevronUp className="w-3.5 h-3.5 ml-1 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5 ml-1 text-slate-400" />
                    )}
                  </button>
                </div>
              </div>

              {/* Collapsible "Why?" Section */}
              {isExpanded && (
                <div className="mt-4 pt-4 border-t border-slate-100 space-y-3 animate-fadeIn">
                  <div className="text-xs text-slate-600">
                    <strong>Diagnosis:</strong> {getSlotDiagnosis(ts)}
                  </div>

                  {/* 5 Component Mini-Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">Attendance</div>
                      <div className="font-mono font-bold text-slate-900 mt-0.5">{s.Attendance_Score} <span className="text-[10px] font-normal text-slate-400">/ 40</span></div>
                      <div className="text-[10px] text-slate-500 mt-0.5">{s.Average_Attendance}% avg</div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">Preference</div>
                      <div className="font-mono font-bold text-slate-900 mt-0.5">{s.Preference_Score} <span className="text-[10px] font-normal text-slate-400">/ 25</span></div>
                      <div className="text-[10px] text-slate-500 mt-0.5">{s.Preference_Responses} votes</div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">Concentration</div>
                      <div className="font-mono font-bold text-slate-900 mt-0.5">{s.Concentration_Score} <span className="text-[10px] font-normal text-slate-400">/ 15</span></div>
                      <div className="text-[10px] text-slate-500 mt-0.5">Survey fatigue</div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">Schedule</div>
                      <div className="font-mono font-bold text-slate-900 mt-0.5">{s.Schedule_Score} <span className="text-[10px] font-normal text-slate-400">/ 10</span></div>
                      <div className="text-[10px] text-slate-500 mt-0.5">Gaps + cont.</div>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">On-Time</div>
                      <div className="font-mono font-bold text-slate-900 mt-0.5">{s.On_Time_Score} <span className="text-[10px] font-normal text-slate-400">/ 10</span></div>
                      <div className="text-[10px] text-slate-500 mt-0.5">80.6% on-time</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
