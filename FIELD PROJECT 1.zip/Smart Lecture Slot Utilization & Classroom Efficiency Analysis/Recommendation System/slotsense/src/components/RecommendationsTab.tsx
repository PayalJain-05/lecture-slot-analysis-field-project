import React, { useState, useMemo } from 'react';
import { 
  Sparkles, 
  ArrowDown, 
  Download, 
  ChevronDown, 
  ChevronUp, 
  Check, 
  TrendingUp,
  Filter
} from 'lucide-react';
import { slotSenseData } from '../utils/recommendationEngine';

export const RecommendationsTab: React.FC = () => {
  const recommendations = slotSenseData.recommendations;

  // Filters
  const [selectedDay, setSelectedDay] = useState<string>('All');
  const [selectedDivision, setSelectedDivision] = useState<string>('All');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const daysList = ['All', ...Array.from(new Set(recommendations.map(r => r.Day)))];
  const divisionsList = ['All', ...Array.from(new Set(recommendations.map(r => r.Division))).sort()];

  const filteredRecs = useMemo(() => {
    return recommendations.filter(r => {
      if (selectedDay !== 'All' && r.Day !== selectedDay) return false;
      if (selectedDivision !== 'All' && r.Division !== selectedDivision) return false;
      return true;
    });
  }, [recommendations, selectedDay, selectedDivision]);

  const handleExportCSV = () => {
    const headers = [
      'Day',
      'Division',
      'Subject',
      'Current_Slot',
      'Current_Classroom',
      'Current_Score',
      'Recommended_Slot',
      'Recommended_Classroom',
      'Recommended_Score',
      'Score_Improvement'
    ];
    const rows = filteredRecs.map(r => [
      r.Day,
      r.Division,
      r.Subject,
      `"${r.Current_Slot}"`,
      r.Current_Classroom,
      r.Current_Score,
      `"${r.Recommended_Slot}"`,
      r.Recommended_Classroom,
      r.Recommended_Score,
      r.Score_Improvement
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `slotsense_recommendations.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Timetable Recommendations
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              15 conflict-free schedule migrations with guaranteed room capacity and zero division collision.
            </p>
          </div>

          <button
            onClick={handleExportCSV}
            className="inline-flex items-center px-3.5 py-2 text-xs font-semibold rounded-xl bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 transition-colors w-fit shadow-2xs"
          >
            <Download className="w-3.5 h-3.5 mr-1.5 text-slate-500" />
            Export CSV
          </button>
        </div>

        {/* Filter Toolbar */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-3">
          <div className="flex items-center space-x-1 text-xs text-slate-500">
            <Filter className="w-3.5 h-3.5 mr-1 text-slate-400" />
            <span>Filters:</span>
          </div>

          <select
            value={selectedDay}
            onChange={e => setSelectedDay(e.target.value)}
            className="px-2.5 py-1 text-xs rounded-lg border border-slate-200 bg-white text-slate-800 font-medium focus:outline-none"
          >
            {daysList.map(d => (
              <option key={d} value={d}>{d === 'All' ? 'All Days' : d}</option>
            ))}
          </select>

          <select
            value={selectedDivision}
            onChange={e => setSelectedDivision(e.target.value)}
            className="px-2.5 py-1 text-xs rounded-lg border border-slate-200 bg-white text-slate-800 font-medium focus:outline-none"
          >
            {divisionsList.map(d => (
              <option key={d} value={d}>{d === 'All' ? 'All Divisions' : `Division ${d}`}</option>
            ))}
          </select>

          <span className="text-[11px] text-slate-400 ml-auto">
            Showing {filteredRecs.length} of {recommendations.length} shifts
          </span>
        </div>
      </div>

      {/* Recommendation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredRecs.map((rec, idx) => {
          const isExpanded = expandedId === idx;

          return (
            <div
              key={idx}
              className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div>
                {/* Card Header: Subject, Div, Day, Score Improvement */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div>
                    <div className="text-sm font-bold text-slate-900">
                      {rec.Subject}
                    </div>
                    <div className="text-xs font-mono text-slate-500 mt-0.5">
                      {rec.Day} • Division {rec.Division}
                    </div>
                  </div>

                  <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-mono font-bold">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                    <span>+{rec.Score_Improvement} pts</span>
                  </div>
                </div>

                {/* Current vs Recommended Flow */}
                <div className="my-4 space-y-2">
                  {/* CURRENT */}
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Current
                    </div>
                    <div className="mt-1 flex items-center justify-between">
                      <span className="font-mono text-xs font-medium text-slate-800">
                        {rec.Current_Slot} → Room {rec.Current_Classroom}
                      </span>
                      <span className="font-mono text-xs font-semibold text-rose-600">
                        {rec.Current_Score} pts
                      </span>
                    </div>
                  </div>

                  {/* Visual Transition Arrow */}
                  <div className="flex justify-center -my-1">
                    <div className="w-6 h-6 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center shadow-2xs">
                      <ArrowDown className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  {/* RECOMMENDED */}
                  <div className="p-3 rounded-xl bg-indigo-50/40 border border-indigo-100">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-700">
                      Recommended
                    </div>
                    <div className="mt-1 flex items-center justify-between">
                      <span className="font-mono text-xs font-semibold text-slate-900">
                        {rec.Recommended_Slot} → Room {rec.Recommended_Classroom}
                      </span>
                      <span className="font-mono text-xs font-bold text-emerald-700">
                        {rec.Recommended_Score} pts
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* View Details Toggle */}
              <div>
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-1 text-[11px] text-emerald-700 font-medium">
                    <Check className="w-3 h-3 text-emerald-600" />
                    <span>Conflict-Free Verified</span>
                  </div>

                  <button
                    onClick={() => setExpandedId(isExpanded ? null : idx)}
                    className="text-xs font-medium text-slate-500 hover:text-slate-900 inline-flex items-center transition-colors"
                  >
                    <span>{isExpanded ? 'Hide Details' : 'View Details'}</span>
                    {isExpanded ? (
                      <ChevronUp className="w-3.5 h-3.5 ml-1" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5 ml-1" />
                    )}
                  </button>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="mt-3 p-3 bg-slate-50 rounded-xl text-xs text-slate-600 space-y-1.5 border border-slate-200/80 animate-fadeIn">
                    <div>
                      <strong>Algorithmic Rationale:</strong> Reallocates from low-scoring period ({rec.Current_Score}) to higher engagement slot ({rec.Recommended_Score}).
                    </div>
                    <div className="text-[11px] text-slate-500 pt-1">
                      {rec.Current_Classroom === rec.Recommended_Classroom ? (
                        <span>• Classroom {rec.Current_Classroom} preserved (zero student relocation needed).</span>
                      ) : (
                        <span>• Reassigned to {rec.Recommended_Classroom} with verified capacity fit.</span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
