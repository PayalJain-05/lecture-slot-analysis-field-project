import React from 'react';
import { 
  AlertTriangle, 
  Sparkles, 
  Building2, 
  Users, 
  ArrowRight,
  TrendingUp,
  TrendingDown,
  Clock,
  ArrowUpRight
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine,
  Cell
} from 'recharts';
import { slotSenseData } from '../utils/recommendationEngine';
import { TabType } from './Navbar';

interface DashboardTabProps {
  setActiveTab: (tab: TabType) => void;
  onSelectSlot?: (slot: string) => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ setActiveTab, onSelectSlot }) => {
  const { summary, slot_scores, all_time_slots, recommendations } = slotSenseData;

  const chartData = all_time_slots.map(ts => {
    const s = slot_scores[ts];
    return {
      slot: ts,
      score: s.Total_Score,
      attendance: s.Attendance_Score,
      preference: s.Preference_Score,
      avgAtt: s.Average_Attendance,
      isProblem: s.Is_Problem
    };
  });

  // Top 3 highest improvement recommendations
  const topRecommendations = [...recommendations]
    .sort((a, b) => b.Score_Improvement - a.Score_Improvement)
    .slice(0, 3);

  return (
    <div className="space-y-6">
      {/* Compact Header Section */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Lecture Slot Utilization &amp; Classroom Efficiency
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Field intelligence across 480 timetable slots, 10 classrooms, and 200 student survey responses.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setActiveTab('recommendations')}
              className="inline-flex items-center px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-colors shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
              Recommendations ({summary.total_recommendations})
            </button>
            <button
              onClick={() => setActiveTab('check-lecture')}
              className="inline-flex items-center px-3.5 py-2 text-xs font-semibold rounded-xl bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 transition-colors"
            >
              Analyze a Lecture
              <ArrowRight className="w-3.5 h-3.5 ml-1.5 text-slate-400" />
            </button>
          </div>
        </div>
      </div>

      {/* 4 Clean KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Problem Slots */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs transition-all hover:border-slate-300">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Problem Slots</span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono text-slate-900">
              {summary.total_problem_lectures}
            </span>
            <span className="text-[11px] font-medium text-rose-600">
              &lt; 60 pts
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Out of {summary.total_lecture_sessions} scheduled sessions
          </div>
        </div>

        {/* KPI 2: Recommendations */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs transition-all hover:border-slate-300">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Recommendations</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono text-slate-900">
              {summary.total_recommendations}
            </span>
            <span className="text-[11px] font-medium text-emerald-600">
              +10.2 avg boost
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            Conflict-free slot migrations
          </div>
        </div>

        {/* KPI 3: Classrooms */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs transition-all hover:border-slate-300">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Classrooms</span>
            <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono text-slate-900">
              {summary.total_classrooms}
            </span>
            <span className="text-[11px] font-medium text-slate-500">
              Wings A, B, C
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            120 physical field audits
          </div>
        </div>

        {/* KPI 4: Student Responses */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs transition-all hover:border-slate-300">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Student Responses</span>
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono text-slate-900">
              {summary.total_survey_responses}
            </span>
            <span className="text-[11px] font-medium text-indigo-600">
              Divisions A–K
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            80.6% on-time punctuality rate
          </div>
        </div>
      </div>

      {/* Main Visualization & Secondary Insight Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Primary Chart: Slot Efficiency Profile */}
        <div className="lg:col-span-8 bg-white border border-slate-200/80 rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-sm font-bold text-slate-900">Lecture Slot Efficiency Profile</h2>
                <p className="text-xs text-slate-500">Efficiency score (0–100) across academic day slots</p>
              </div>

              <div className="flex items-center space-x-3 text-xs">
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  <span className="text-slate-600 font-medium">≥ 60 Optimal</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                  <span className="text-slate-600 font-medium">&lt; 60 Problem</span>
                </div>
              </div>
            </div>

            <div className="h-64 mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="slot" 
                    tick={{ fill: '#64748b', fontSize: 11, fontFamily: 'monospace' }} 
                    tickLine={false}
                    axisLine={{ stroke: '#e2e8f0' }}
                  />
                  <YAxis 
                    domain={[0, 100]} 
                    ticks={[0, 20, 40, 60, 80, 100]} 
                    tick={{ fill: '#64748b', fontSize: 11 }}
                    tickLine={false}
                    axisLine={{ stroke: '#e2e8f0' }}
                  />
                  <Tooltip 
                    cursor={{ fill: 'rgba(241, 245, 249, 0.6)' }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 text-white px-3 py-2 rounded-xl shadow-md text-xs space-y-1">
                            <div className="font-bold font-mono">{d.slot}</div>
                            <div className="text-slate-300">Score: <strong className="text-indigo-300 font-mono">{d.score}</strong> / 100</div>
                            <div className="text-slate-400 text-[11px]">Avg Attendance: {d.avgAtt}%</div>
                            <div className={`text-[10px] font-semibold ${d.isProblem ? 'text-rose-400' : 'text-emerald-400'}`}>
                              {d.isProblem ? 'Problem Slot' : 'Optimal Slot'}
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <ReferenceLine 
                    y={60} 
                    stroke="#f43f5e" 
                    strokeDasharray="4 4" 
                    label={{ value: '60 Pt Line', fill: '#f43f5e', fontSize: 10, position: 'right' }} 
                  />
                  <Bar dataKey="score" radius={[5, 5, 0, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.score >= 60 ? '#10b981' : '#f43f5e'} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Click any slot in the scoring tab for deep factor decomposition</span>
            <button 
              onClick={() => setActiveTab('slot-analysis')}
              className="font-semibold text-indigo-600 hover:text-indigo-700 inline-flex items-center"
            >
              Explore all slots <ArrowRight className="w-3 h-3 ml-1" />
            </button>
          </div>
        </div>

        {/* Secondary Insights Column */}
        <div className="lg:col-span-4 space-y-4">
          {/* Insight 1: Peak Window */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-4 sm:p-5 shadow-xs">
            <div className="flex items-center space-x-2 text-emerald-700 text-xs font-semibold mb-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              <span>Peak Window (1:00–2:20 PM)</span>
            </div>
            <div className="text-xs text-slate-600 space-y-1">
              <p>Highest engagement period of the day.</p>
              <div className="mt-2 p-2 rounded-lg bg-emerald-50/60 border border-emerald-100 font-mono text-[11px] text-emerald-900 flex justify-between">
                <span>1:00–1:40 PM: <strong>69.77</strong></span>
                <span>1:40–2:20 PM: <strong>62.90</strong></span>
              </div>
            </div>
          </div>

          {/* Insight 2: Fatigue Drop */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-4 sm:p-5 shadow-xs">
            <div className="flex items-center space-x-2 text-rose-700 text-xs font-semibold mb-2">
              <TrendingDown className="w-4 h-4 text-rose-600" />
              <span>Late Fatigue (4:50–6:50 PM)</span>
            </div>
            <div className="text-xs text-slate-600 space-y-1">
              <p>Severe drops due to consecutive hours and commuter departure.</p>
              <div className="mt-2 p-2 rounded-lg bg-rose-50/60 border border-rose-100 font-mono text-[11px] text-rose-900 flex justify-between">
                <span>4:50–5:30 PM: <strong>38.04</strong></span>
                <span>6:10–6:50 PM: <strong>39.62</strong></span>
              </div>
            </div>
          </div>

          {/* Quick Stat Bar */}
          <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 shadow-xs flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-400 font-medium">Conflict-Free Shifts</div>
              <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">15 Ready</div>
            </div>
            <button
              onClick={() => setActiveTab('recommendations')}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition-colors"
            >
              Review Shifts
            </button>
          </div>
        </div>
      </div>

      {/* Compact Top Recommendations Section */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Top Optimization Opportunities</h2>
            <p className="text-xs text-slate-500">Highest score improvements with verified classroom capacity</p>
          </div>
          <button
            onClick={() => setActiveTab('recommendations')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 inline-flex items-center"
          >
            View all 15 <ArrowUpRight className="w-3.5 h-3.5 ml-1" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          {topRecommendations.map((rec, i) => (
            <div
              key={i}
              className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/60 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-mono text-slate-900">
                    Div {rec.Division} • {rec.Day}
                  </span>
                  <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                    +{rec.Score_Improvement} pts
                  </span>
                </div>

                <div className="mt-2 text-xs font-semibold text-slate-800">
                  {rec.Subject}
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-200/60 text-xs space-y-1 font-mono">
                  <div className="text-slate-500 flex justify-between">
                    <span>{rec.Current_Slot} ({rec.Current_Classroom})</span>
                    <span className="text-rose-600 font-semibold">{rec.Current_Score}</span>
                  </div>
                  <div className="text-slate-900 font-semibold flex justify-between">
                    <span>{rec.Recommended_Slot} ({rec.Recommended_Classroom})</span>
                    <span className="text-emerald-700">{rec.Recommended_Score}</span>
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-2 text-[10px] text-slate-400 font-medium flex items-center justify-between">
                <span>Room capacity verified</span>
                <span className="text-emerald-600 font-bold">Conflict-Free</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
