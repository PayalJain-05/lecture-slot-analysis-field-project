import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Search, 
  Tv, 
  Thermometer, 
  SquareCheck, 
  LayoutGrid, 
  Table as TableIcon,
  AlertCircle
} from 'lucide-react';
import { slotSenseData } from '../utils/recommendationEngine';
import { ClassroomStats } from '../types';

export const ClassroomEfficiencyTab: React.FC = () => {
  const { classroom_stats } = slotSenseData;
  const classroomsList = Object.values(classroom_stats);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedWing, setSelectedWing] = useState('All');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Compute status for classroom based on utilization percentage
  const getRoomStatus = (c: ClassroomStats): 'Optimal' | 'Overcrowded' | 'Underutilized' | 'Vacant' => {
    if (c.average_students === 0) return 'Vacant';
    if (c.utilization_percentage > 90) return 'Overcrowded';
    if (c.utilization_percentage >= 65) return 'Optimal';
    return 'Underutilized';
  };

  const getStatusBadge = (status: 'Optimal' | 'Overcrowded' | 'Underutilized' | 'Vacant') => {
    switch (status) {
      case 'Optimal':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Overcrowded':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      case 'Underutilized':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Vacant':
        return 'bg-slate-100 text-slate-600 border-slate-200';
    }
  };

  const filteredClassrooms = useMemo(() => {
    return classroomsList.filter(c => {
      if (searchQuery && !c.classroom.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      if (selectedWing !== 'All') {
        const wing = c.classroom.charAt(0);
        if (wing !== selectedWing) return false;
      }
      return true;
    }).sort((a, b) => b.utilization_percentage - a.utilization_percentage);
  }, [classroomsList, searchQuery, selectedWing]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Classroom Capacity &amp; Utilization
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Field observations across 10 monitored rooms in Wings A, B, and C.
            </p>
          </div>

          {/* View Toggle */}
          <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs font-medium transition-all ${
                viewMode === 'grid' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs font-medium transition-all ${
                viewMode === 'table' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Table View"
            >
              <TableIcon className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search & Wing Filters */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search classroom..."
                className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-slate-900 w-48 font-mono"
              />
            </div>

            <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-xl text-xs">
              {['All', 'A', 'B', 'C'].map(w => (
                <button
                  key={w}
                  onClick={() => setSelectedWing(w)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                    selectedWing === w ? 'bg-white text-slate-900 font-bold shadow-2xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {w === 'All' ? 'All Wings' : `Wing ${w}`}
                </button>
              ))}
            </div>
          </div>

          <div className="text-xs text-slate-400">
            {filteredClassrooms.length} classrooms monitored
          </div>
        </div>
      </div>

      {/* Grid Mode */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredClassrooms.map(c => {
            const status = getRoomStatus(c);
            const totalIssues = c.issues.ac_issues + c.issues.fan_issues + c.issues.lighting_issues + c.issues.seating_issues + c.issues.noise_issues;

            return (
              <div
                key={c.classroom}
                className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Room Name & Status */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div className="flex items-center space-x-2">
                      <span className="text-lg font-bold font-mono text-slate-900">{c.classroom}</span>
                      <span className="text-xs px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium">
                        Wing {c.classroom.charAt(0)}
                      </span>
                    </div>

                    <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadge(status)}`}>
                      {status}
                    </span>
                  </div>

                  {/* Utilization Metrics */}
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-500 font-medium">Capacity Utilization</span>
                      <span className="font-mono font-bold text-slate-900">{c.utilization_percentage}%</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          c.utilization_percentage >= 65 ? 'bg-emerald-500' : 'bg-amber-500'
                        }`}
                        style={{ width: `${Math.min(c.utilization_percentage, 100)}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                      <span>Avg: {c.average_students} students</span>
                      <span>Cap: {c.capacity} seats</span>
                    </div>
                  </div>

                  {/* Amenities & Facility Issues */}
                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-3 text-slate-500 text-[11px]">
                      <span className="flex items-center" title="Projector">
                        <Tv className="w-3.5 h-3.5 mr-1 text-slate-400" />
                        {c.projector_available === 'Yes' ? 'Yes' : 'No'}
                      </span>
                      <span className="flex items-center" title="Air Conditioning">
                        <Thermometer className="w-3.5 h-3.5 mr-1 text-slate-400" />
                        {c.ac_available === 'Yes' ? 'AC' : 'No AC'}
                      </span>
                      <span className="flex items-center" title="Whiteboard">
                        <SquareCheck className="w-3.5 h-3.5 mr-1 text-slate-400" />
                        Board
                      </span>
                    </div>

                    <div className="flex items-center space-x-1">
                      <AlertCircle className={`w-3.5 h-3.5 ${totalIssues > 5 ? 'text-rose-500' : 'text-slate-400'}`} />
                      <span className={`text-xs font-mono font-semibold ${totalIssues > 5 ? 'text-rose-600' : 'text-slate-600'}`}>
                        {totalIssues} {totalIssues === 1 ? 'issue' : 'issues'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2 text-[10px] text-slate-400 border-t border-slate-100 flex justify-between">
                  <span>{c.room_type}</span>
                  <span>{c.observations_count} audit sessions</span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Compact Table Mode */
        <div className="bg-white border border-slate-200/80 rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase font-semibold border-b border-slate-100">
                <tr>
                  <th className="px-4 py-3">Classroom</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Capacity</th>
                  <th className="px-4 py-3">Avg Present</th>
                  <th className="px-4 py-3">Utilization</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Facility Issues</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredClassrooms.map(c => {
                  const status = getRoomStatus(c);
                  const totalIssues = c.issues.ac_issues + c.issues.fan_issues + c.issues.lighting_issues + c.issues.seating_issues + c.issues.noise_issues;

                  return (
                    <tr key={c.classroom} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-4 py-3 font-mono font-bold text-slate-900">{c.classroom}</td>
                      <td className="px-4 py-3 text-slate-600">{c.room_type}</td>
                      <td className="px-4 py-3 font-mono text-slate-700">{c.capacity}</td>
                      <td className="px-4 py-3 font-mono text-slate-700">{c.average_students}</td>
                      <td className="px-4 py-3 font-mono font-bold text-slate-900">
                        {c.utilization_percentage}%
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadge(status)}`}>
                          {status}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono">
                        <span className={totalIssues > 5 ? 'text-rose-600 font-bold' : 'text-slate-600'}>
                          {totalIssues} recorded
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
