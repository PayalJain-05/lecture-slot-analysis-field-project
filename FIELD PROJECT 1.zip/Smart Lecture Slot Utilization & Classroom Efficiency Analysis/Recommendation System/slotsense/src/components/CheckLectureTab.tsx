import React, { useState } from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  Building2, 
  Clock, 
  Check, 
  Zap,
  ArrowRight
} from 'lucide-react';
import { 
  slotSenseData, 
  analyzeLecture, 
  ALL_DIVISIONS, 
  ALL_DAYS, 
  ALL_TIME_SLOTS 
} from '../utils/recommendationEngine';
import { LectureCheckAnalysis } from '../types';

export const CheckLectureTab: React.FC = () => {
  // Selection state
  const [selectedDivision, setSelectedDivision] = useState<string>('E');
  const [selectedDay, setSelectedDay] = useState<string>('Friday');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('6:10-6:50');
  const [subjectInput, setSubjectInput] = useState<string>('CHE');
  const [classroomInput, setClassroomInput] = useState<string>('B201');

  // Analysis result state
  const [analysisResult, setAnalysisResult] = useState<LectureCheckAnalysis>(() => {
    return analyzeLecture({
      division: 'E',
      day: 'Friday',
      timeSlot: '6:10-6:50',
      subject: 'CHE',
      classroom: 'B201'
    });
  });

  const [hasAnalyzed, setHasAnalyzed] = useState<boolean>(true);

  // Auto-fill from timetable if available
  const handleAutoFillFromTimetable = (div: string, day: string, slot: string) => {
    const match = slotSenseData.timetable.find(
      t => t.Division === div && t.Day === day && t.Time_Slot === slot
    );
    if (match) {
      setSubjectInput(match.Subject);
      setClassroomInput(match.Classroom);
    }
  };

  const handleAnalyze = () => {
    const result = analyzeLecture({
      division: selectedDivision,
      day: selectedDay,
      timeSlot: selectedTimeSlot,
      subject: subjectInput || 'Lecture',
      classroom: classroomInput || 'B201'
    });
    setAnalysisResult(result);
    setHasAnalyzed(true);
  };

  const handlePreset = (div: string, day: string, slot: string, sub: string, room: string) => {
    setSelectedDivision(div);
    setSelectedDay(day);
    setSelectedTimeSlot(slot);
    setSubjectInput(sub);
    setClassroomInput(room);
    const result = analyzeLecture({
      division: div,
      day: day,
      timeSlot: slot,
      subject: sub,
      classroom: room
    });
    setAnalysisResult(result);
    setHasAnalyzed(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
          Check a Lecture
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Evaluate any division schedule to inspect slot efficiency score, classroom capacity, and discover better alternatives.
        </p>

        {/* Quick Presets */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center flex-wrap gap-2 text-xs">
          <span className="text-slate-400 font-medium mr-1">Presets:</span>
          <button
            onClick={() => handlePreset('E', 'Friday', '6:10-6:50', 'CHE', 'B201')}
            className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium border border-slate-200 transition-colors"
          >
            Div E • Fri 6:10 PM (CHE)
          </button>
          <button
            onClick={() => handlePreset('G', 'Monday', '4:10-4:50', 'BIO/CS', 'B203')}
            className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium border border-slate-200 transition-colors"
          >
            Div G • Mon 4:10 PM (BIO/CS)
          </button>
          <button
            onClick={() => handlePreset('J', 'Saturday', '4:50-5:30', 'BIO/CS', 'C301')}
            className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium border border-slate-200 transition-colors"
          >
            Div J • Sat 4:50 PM (BIO/CS)
          </button>
          <button
            onClick={() => handlePreset('A', 'Monday', '1:00-1:40', 'PHY', 'A101')}
            className="px-2.5 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium border border-slate-200 transition-colors"
          >
            Div A • Mon 1:00 PM (Optimal)
          </button>
        </div>
      </div>

      {/* Clean Form Layout */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Row 1: Division | Subject */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Division
            </label>
            <select
              value={selectedDivision}
              onChange={e => {
                const val = e.target.value;
                setSelectedDivision(val);
                handleAutoFillFromTimetable(val, selectedDay, selectedTimeSlot);
              }}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
            >
              {ALL_DIVISIONS.map(div => (
                <option key={div} value={div}>Division {div}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Subject
            </label>
            <input
              type="text"
              value={subjectInput}
              onChange={e => setSubjectInput(e.target.value)}
              placeholder="e.g. CHE, MAT, PHY, BIO/CS"
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
            />
          </div>

          {/* Row 2: Day | Current Slot */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Day
            </label>
            <select
              value={selectedDay}
              onChange={e => {
                const val = e.target.value;
                setSelectedDay(val);
                handleAutoFillFromTimetable(selectedDivision, val, selectedTimeSlot);
              }}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
            >
              {ALL_DAYS.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Current Slot
            </label>
            <select
              value={selectedTimeSlot}
              onChange={e => {
                const val = e.target.value;
                setSelectedTimeSlot(val);
                handleAutoFillFromTimetable(selectedDivision, selectedDay, val);
              }}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono font-medium"
            >
              {ALL_TIME_SLOTS.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          {/* Row 3: Classroom */}
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Classroom
            </label>
            <select
              value={classroomInput}
              onChange={e => setClassroomInput(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono font-medium"
            >
              {slotSenseData.classrooms.map(c => (
                <option key={c.Classroom} value={c.Classroom}>
                  {c.Classroom} (Cap: {c.Capacity}, {c.Room_Type})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Prominent Analyze Button */}
        <div className="mt-5 pt-4 border-t border-slate-100 flex justify-end">
          <button
            onClick={handleAnalyze}
            className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-2.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 text-xs font-bold transition-all shadow-xs"
          >
            <Zap className="w-3.5 h-3.5 mr-2 text-indigo-400" />
            Analyze Lecture
          </button>
        </div>
      </div>

      {/* Analysis Result Card */}
      {hasAnalyzed && analysisResult && (
        <div className="space-y-6">
          {/* Status & Score Overview */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-lg font-bold text-slate-900">
                    {analysisResult.subject}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-md bg-slate-100 font-mono text-slate-700 font-medium">
                    Div {analysisResult.division} • {analysisResult.day}
                  </span>
                </div>
                <div className="text-xs text-slate-500 mt-1 font-mono">
                  {analysisResult.time_slot} in {analysisResult.classroom}
                </div>
              </div>

              {/* Status Badge & Score */}
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="text-[11px] text-slate-400 font-medium">Current Score</div>
                  <div className="font-mono text-2xl font-bold text-slate-900">
                    {analysisResult.current_slot_score.Total_Score}
                    <span className="text-xs text-slate-400 font-normal"> / 100</span>
                  </div>
                </div>

                <span className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${
                  analysisResult.is_problem_slot
                    ? 'bg-rose-50 text-rose-700 border-rose-200'
                    : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                }`}>
                  {analysisResult.is_problem_slot ? 'Problem Slot (<60)' : 'Optimal Slot (≥60)'}
                </span>
              </div>
            </div>

            {/* Key Issues */}
            <div className="mt-4">
              <div className="text-xs font-semibold text-slate-700 mb-2">Key Issues &amp; Metrics:</div>
              {analysisResult.is_problem_slot ? (
                <div className="flex flex-wrap gap-2">
                  <span className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-800 text-xs font-medium border border-rose-100 flex items-center">
                    <AlertTriangle className="w-3 h-3 mr-1.5 text-rose-500" />
                    Low student votes ({analysisResult.current_slot_score.Preference_Responses} out of 79 max)
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-800 text-xs font-medium border border-rose-100 flex items-center">
                    <Clock className="w-3 h-3 mr-1.5 text-rose-500" />
                    Attendance at {analysisResult.current_slot_score.Average_Attendance}% ({analysisResult.current_slot_score.Attendance_Score}/40 pts)
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-slate-50 text-slate-700 text-xs font-medium border border-slate-200 flex items-center">
                    <Building2 className="w-3 h-3 mr-1.5 text-slate-500" />
                    Classroom: {analysisResult.classroom} (Capacity: {analysisResult.classroom_capacity}, Util: {analysisResult.capacity_utilization}%)
                  </span>
                </div>
              ) : (
                <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-medium flex items-center">
                  <CheckCircle2 className="w-4 h-4 mr-2 text-emerald-600" />
                  This lecture is scheduled in a verified high-efficiency slot with optimal attendance.
                </div>
              )}
            </div>
          </div>

          {/* Better Alternatives Section */}
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h2 className="text-sm font-bold text-slate-900">Better Available Alternatives</h2>
                <p className="text-xs text-slate-500">
                  {analysisResult.available_better_alternatives.length > 0 
                    ? `Found ${analysisResult.available_better_alternatives.length} conflict-free candidate slot(s) on ${analysisResult.day}`
                    : `No higher-scoring conflict-free slots free on ${analysisResult.day}`}
                </p>
              </div>
            </div>

            {analysisResult.available_better_alternatives.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                {analysisResult.available_better_alternatives.map((alt, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-sm text-slate-900">
                          {alt.slot}
                        </span>
                        <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                          +{alt.improvement} pts
                        </span>
                      </div>

                      <div className="mt-2 text-xs text-slate-600 flex items-center space-x-2">
                        <span>Room: <strong className="font-mono text-slate-900">{alt.suitable_classroom}</strong></span>
                        <span>•</span>
                        <span>Score: <strong className="font-mono text-emerald-700">{alt.slot_score}</strong> / 100</span>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-200/60 text-[10px] text-emerald-700 font-semibold flex items-center">
                      <Check className="w-3 h-3 mr-1" />
                      Zero Division Conflict • Room Capacity Fit
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-xs text-slate-400 mt-4">
                {analysisResult.is_problem_slot 
                  ? 'All higher slots on this day are currently occupied by other classes or division sessions.'
                  : 'Current slot is already in the optimal range.'}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
