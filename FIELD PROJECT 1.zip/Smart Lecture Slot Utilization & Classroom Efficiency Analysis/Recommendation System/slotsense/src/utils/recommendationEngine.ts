import dataJson from '../data/slotSenseData.json';
import {
  SlotSenseDataBundle,
  SlotScoreData,
  LectureCheckAnalysis,
  ClassroomMaster,
  Recommendation
} from '../types';

export const slotSenseData = (dataJson as unknown) as SlotSenseDataBundle;

export const ALL_TIME_SLOTS = slotSenseData.all_time_slots;
export const ALL_DIVISIONS = Array.from(new Set(slotSenseData.timetable.map(t => t.Division))).sort();
export const ALL_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/**
 * Perform exact rule-based analysis on any selected lecture
 */
export function analyzeLecture(params: {
  division: string;
  day: string;
  timeSlot: string;
  subject?: string;
  classroom?: string;
}): LectureCheckAnalysis {
  const { division, day, timeSlot } = params;

  // 1. Current slot score
  const currentSlotScore = slotSenseData.slot_scores[timeSlot] || {
    Time_Slot: timeSlot,
    Attendance_Score: 0,
    Preference_Score: 0,
    Concentration_Score: slotSenseData.survey_insights.concentration_score,
    Schedule_Score: slotSenseData.survey_insights.schedule_score,
    On_Time_Score: slotSenseData.survey_insights.on_time_score,
    Total_Score: 0,
    Average_Attendance: 0,
    Preference_Responses: 0,
    Is_Problem: true
  };

  const isProblemSlot = currentSlotScore.Total_Score < 60;

  // 2. Division estimated students
  const estimatedStudents = slotSenseData.division_student_estimates[division] || 45;

  // 3. Find matched lecture or use params
  const matchedLecture = slotSenseData.timetable.find(
    t => t.Division === division && t.Day === day && t.Time_Slot === timeSlot
  );

  const subject = params.subject || matchedLecture?.Subject || 'Lecture';
  const classroomName = params.classroom || matchedLecture?.Classroom || 'A101';

  // Classroom stats
  const roomMaster = slotSenseData.classrooms.find(c => c.Classroom === classroomName);
  const roomCapacity = roomMaster ? roomMaster.Capacity : 60;
  const roomStats = slotSenseData.classroom_stats[classroomName] || null;
  const isClassroomSuitable = roomCapacity >= estimatedStudents;
  const capacityUtilization = Math.round((estimatedStudents / roomCapacity) * 100);

  // 4. Determine division's busy slots on this day
  const divisionBusySlots = slotSenseData.timetable
    .filter(t => t.Division === division && t.Day === day && t.Session_Type === 'Lecture')
    .map(t => t.Time_Slot);

  // 5. Look for better available alternative slots
  const availableBetterAlternatives: LectureCheckAnalysis['available_better_alternatives'] = [];

  for (const altSlot of ALL_TIME_SLOTS) {
    if (altSlot === timeSlot) continue;
    if (divisionBusySlots.includes(altSlot)) continue; // division already has class

    const altScoreObj = slotSenseData.slot_scores[altSlot];
    if (!altScoreObj) continue;
    const altScore = altScoreObj.Total_Score;

    if (altScore <= currentSlotScore.Total_Score) continue;

    // Find classrooms occupied at this alt slot on this day
    const occupiedClassrooms = new Set(
      slotSenseData.timetable
        .filter(t => t.Day === day && t.Time_Slot === altSlot && t.Classroom && t.Classroom !== 'N/A')
        .map(t => t.Classroom)
    );

    // Filter available rooms with capacity >= estimated students
    const suitableRooms = slotSenseData.classrooms.filter(
      c => !occupiedClassrooms.has(c.Classroom) && c.Capacity >= estimatedStudents
    );

    let chosenRoom = '';
    if (suitableRooms.some(r => r.Classroom === classroomName)) {
      chosenRoom = classroomName; // maintain current room if available & fits
    } else if (suitableRooms.length > 0) {
      chosenRoom = suitableRooms[0].Classroom;
    }

    if (chosenRoom) {
      availableBetterAlternatives.push({
        slot: altSlot,
        slot_score: altScore,
        improvement: Math.round((altScore - currentSlotScore.Total_Score) * 100) / 100,
        suitable_classroom: chosenRoom,
        is_conflict_free: true
      });
    }
  }

  // Sort by highest score improvement
  availableBetterAlternatives.sort((a, b) => b.improvement - a.improvement);

  // 6. Generate explainable diagnosis bullets
  const explanation: string[] = [];

  if (isProblemSlot) {
    explanation.push(
      `Current slot ${timeSlot} has an efficiency score of ${currentSlotScore.Total_Score}/100, which is classified as an inefficient / problem slot (< 60.0).`
    );
  } else {
    explanation.push(
      `Current slot ${timeSlot} operates at an acceptable efficiency score of ${currentSlotScore.Total_Score}/100 (≥ 60.0).`
    );
  }

  // Attendance factor
  explanation.push(
    `Observed field attendance in ${timeSlot} averages ${currentSlotScore.Average_Attendance}% (yielding an Attendance Score of ${currentSlotScore.Attendance_Score}/40).`
  );

  // Student comfort
  if (currentSlotScore.Preference_Responses <= 10) {
    explanation.push(
      `Low student preference: Only ${currentSlotScore.Preference_Responses} out of ${slotSenseData.survey_insights.total_responses} survey respondents found this slot comfortable (Preference Score: ${currentSlotScore.Preference_Score}/25).`
    );
  } else {
    explanation.push(
      `High student preference: ${currentSlotScore.Preference_Responses} survey respondents selected this timing as their preferred comfort window (Preference Score: ${currentSlotScore.Preference_Score}/25).`
    );
  }

  // Capacity check
  if (!isClassroomSuitable) {
    explanation.push(
      `Classroom mismatch: Room ${classroomName} has a capacity of ${roomCapacity}, which is smaller than Division ${division}'s estimated student count of ${estimatedStudents} (${capacityUtilization}% utilization).`
    );
  } else {
    explanation.push(
      `Classroom sizing: Room ${classroomName} capacity is ${roomCapacity} seats for ${estimatedStudents} students (${capacityUtilization}% utilization).`
    );
  }

  // Environmental issues check
  if (roomStats) {
    const issuesList: string[] = [];
    if (roomStats.issues.ac_issues > 0) issuesList.push(`AC/Temperature (${roomStats.issues.ac_issues} reports)`);
    if (roomStats.issues.fan_issues > 0) issuesList.push(`Fan/Ventilation (${roomStats.issues.fan_issues} reports)`);
    if (roomStats.issues.lighting_issues > 0) issuesList.push(`Lighting (${roomStats.issues.lighting_issues} reports)`);
    if (roomStats.issues.seating_issues > 0) issuesList.push(`Seating/Chairs (${roomStats.issues.seating_issues} reports)`);
    if (roomStats.issues.noise_issues > 0) issuesList.push(`External Noise (${roomStats.issues.noise_issues} reports)`);

    if (issuesList.length > 0) {
      explanation.push(
        `Classroom observation warnings: ${issuesList.join(', ')} logged in ${classroomName}.`
      );
    }
  }

  // Alternatives conclusion
  if (availableBetterAlternatives.length > 0) {
    const best = availableBetterAlternatives[0];
    explanation.push(
      `Recommended Action: Shift to slot ${best.slot} in ${best.suitable_classroom}, raising efficiency by +${best.improvement} points (to ${best.slot_score}/100) with zero schedule or room collision.`
    );
  } else if (isProblemSlot) {
    explanation.push(
      `No conflict-free alternative slot with higher score exists for Division ${division} on ${day} due to full division schedule constraints.`
    );
  }

  return {
    division,
    day,
    subject,
    classroom: classroomName,
    time_slot: timeSlot,
    current_slot_score: currentSlotScore,
    is_problem_slot: isProblemSlot,
    estimated_students: estimatedStudents,
    classroom_capacity: roomCapacity,
    capacity_utilization: capacityUtilization,
    is_classroom_suitable: isClassroomSuitable,
    classroom_issues: roomStats ? roomStats.issues : null,
    classroom_status: roomStats ? roomStats.utilization_status : 'Normal',
    available_better_alternatives: availableBetterAlternatives,
    explanation
  };
}

/**
 * Filter timetable lectures
 */
export function getFilteredTimetable(filter: {
  division?: string;
  day?: string;
  timeSlot?: string;
  classroom?: string;
  isProblemOnly?: boolean;
}) {
  return slotSenseData.timetable.filter(row => {
    if (filter.division && row.Division !== filter.division) return false;
    if (filter.day && row.Day !== filter.day) return false;
    if (filter.timeSlot && row.Time_Slot !== filter.timeSlot) return false;
    if (filter.classroom && row.Classroom !== filter.classroom) return false;
    if (filter.isProblemOnly) {
      const score = slotSenseData.slot_scores[row.Time_Slot]?.Total_Score ?? 100;
      if (score >= 60 || row.Subject === 'FREE' || row.Session_Type !== 'Lecture') return false;
    }
    return true;
  });
}
