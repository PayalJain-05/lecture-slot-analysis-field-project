import React, { useState } from 'react';
import { Navbar, TabType } from './components/Navbar';
import { DashboardTab } from './components/DashboardTab';
import { SlotAnalysisTab } from './components/SlotAnalysisTab';
import { CheckLectureTab } from './components/CheckLectureTab';
import { RecommendationsTab } from './components/RecommendationsTab';
import { ClassroomEfficiencyTab } from './components/ClassroomEfficiencyTab';
import { GraduationCap } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [selectedSlotForAnalysis, setSelectedSlotForAnalysis] = useState<string>('1:00-1:40');

  const handleSelectSlot = (slot: string) => {
    setSelectedSlotForAnalysis(slot);
    setActiveTab('slot-analysis');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Header Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && (
          <DashboardTab 
            setActiveTab={setActiveTab} 
            onSelectSlot={handleSelectSlot} 
          />
        )}

        {activeTab === 'slot-analysis' && (
          <SlotAnalysisTab initialSlot={selectedSlotForAnalysis} />
        )}

        {activeTab === 'check-lecture' && (
          <CheckLectureTab />
        )}

        {activeTab === 'recommendations' && (
          <RecommendationsTab />
        )}

        {activeTab === 'classrooms' && (
          <ClassroomEfficiencyTab />
        )}
      </main>

      {/* Clean Streamlined Footer */}
      <footer className="bg-white border-t border-slate-200/80 mt-12 py-6 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <div className="w-5 h-5 rounded bg-slate-900 text-white flex items-center justify-center">
              <GraduationCap className="w-3 h-3 text-indigo-400" />
            </div>
            <span className="font-bold text-slate-800">SlotSense</span>
            <span>• College Project: Smart Lecture Slot &amp; Classroom Efficiency</span>
          </div>

          <div className="text-slate-400 text-[11px]">
            Empirical field dataset analysis across 480 slots &amp; 10 classrooms
          </div>
        </div>
      </footer>
    </div>
  );
}
