export interface SlotScoreData {
  Time_Slot: string;
  Attendance_Score: number;
  Preference_Score: number;
  Concentration_Score: number;
  Schedule_Score: number;
  On_Time_Score: number;
  Total_Score: number;
  Average_Attendance: number;
  Preference_Responses: number;
  Is_Problem: boolean;
}

export interface ClassroomMaster {
  Classroom: string;
  Room_Type: string;
  Capacity: number;
  Floor: string;
  Building_Wing: string;
  Room_Size_Category: string;
  AC_Available: string;
  Projector_Available: string;
  Whiteboard_Available: string;
  Minimum_Suitable_Class_Size: number;
  Maximum_Suitable_Class_Size: number;
}

export interface ClassroomIssues {
  ac_issues: number;
  fan_issues: number;
  lighting_issues: number;
  seating_issues: number;
  noise_issues: number;
  other_issues: string[];
}

export interface ClassroomStats {
  classroom: string;
  capacity: number;
  room_type: string;
  ac_available: string;
  projector_available: string;
  whiteboard_available: string;
  room_size_category: string;
  average_students: number;
  observations_count: number;
  utilization_percentage: number;
  utilization_status: string;
  status_counts: Record<string, number>;
  issues: ClassroomIssues;
}

export interface Recommendation {
  Day: string;
  Division: string;
  Subject: string;
  Current_Slot: string;
  Recommended_Slot: string;
  Current_Classroom: string;
  Recommended_Classroom: string;
  Current_Score: number;
  Recommended_Score: number;
  Score_Improvement: number;
}

export interface AlternativeSlot {
  Day: string;
  Division: string;
  Subject: string;
  Classroom: string;
  Current_Slot: string;
  Current_Score: number;
  Alternative_Slot: string;
  Alternative_Score: number;
  Score_Improvement: number;
}

export interface TimetableRow {
  Day: string;
  Division: string;
  Time_Slot: string;
  Subject: string;
  Teacher: string;
  Classroom: string;
  Session_Type: string;
}

export interface ObservationRow {
  Observation_ID: string;
  Date: string;
  Day: string;
  Time_Slot: string;
  Classroom: string;
  Division: string;
  Subject: string;
  Teacher: string;
  Students_Present: number;
  Classroom_Capacity: number;
  Attendance_Percentage: number;
  Started_On_Time: string;
  Ended_On_Time: string;
  Utilization_Status: string;
  AC_Temperature_Issue: string;
  Fan_Ventilation_Issue: string;
  Lighting_Issue: string;
  Seating_Issue: string;
  Noise_Issue: string;
  Other_Issue: string;
}

export interface SurveyInsights {
  total_responses: number;
  concentration_score: number;
  schedule_score: number;
  on_time_score: number;
  comfortable_timings: Record<string, number>;
  concentration_counts: Record<string, number>;
  continuous_counts: Record<string, number>;
  gaps_counts: Record<string, number>;
  start_on_time_rate: number;
  end_on_time_rate: number;
}

export interface SlotSenseDataBundle {
  summary: {
    total_lectures: number;
    total_lecture_sessions: number;
    total_free_slots: number;
    total_classrooms: number;
    total_observations: number;
    total_survey_responses: number;
    total_problem_lectures: number;
    total_alternatives_found: number;
    total_recommendations: number;
    average_slot_score: number;
  };
  slot_scores: Record<string, SlotScoreData>;
  all_time_slots: string[];
  classrooms: ClassroomMaster[];
  classroom_stats: Record<string, ClassroomStats>;
  division_student_estimates: Record<string, number>;
  recommendations: Recommendation[];
  alternative_slots: AlternativeSlot[];
  survey_insights: SurveyInsights;
  observations: ObservationRow[];
  timetable: TimetableRow[];
}

export interface LectureCheckAnalysis {
  division: string;
  day: string;
  subject: string;
  classroom: string;
  time_slot: string;
  current_slot_score: SlotScoreData;
  is_problem_slot: boolean;
  estimated_students: number;
  classroom_capacity: number;
  capacity_utilization: number;
  is_classroom_suitable: boolean;
  classroom_issues: ClassroomIssues | null;
  classroom_status: string;
  available_better_alternatives: {
    slot: string;
    slot_score: number;
    improvement: number;
    suitable_classroom: string;
    is_conflict_free: boolean;
  }[];
  explanation: string[];
}
