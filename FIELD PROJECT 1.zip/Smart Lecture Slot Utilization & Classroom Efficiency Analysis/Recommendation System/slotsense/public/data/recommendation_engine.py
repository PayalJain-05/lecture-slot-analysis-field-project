import csv
from collections import Counter, defaultdict

# ----------------------------------------------------
# 1. LOAD DATASETS
# ----------------------------------------------------
with open('cleaned_classroom_master_data.csv', encoding='utf-8-sig') as f:
    classroom_master = list(csv.DictReader(f))
    for c in classroom_master:
        c['Capacity'] = int(c['Capacity'])

with open('cleaned_student_survey.csv', encoding='utf-8-sig') as f:
    student_survey = list(csv.DictReader(f))

with open('cleaned_classroom_observation.csv', encoding='utf-8-sig') as f:
    classroom_observation = list(csv.DictReader(f))
    for o in classroom_observation:
        o['Students_Present'] = float(o['Students_Present'])
        o['Attendance_Percentage'] = float(o['Attendance_Percentage'])
        o['Time_Slot'] = o['Time_Slot'].strip()

with open('cleaned_combined_timetable_data.csv', encoding='utf-8-sig') as f:
    timetable_df = []
    for row in csv.DictReader(f):
        if not row.get('Day') or not row.get('Time_Slot'):
            continue
        cleaned_row = {k: v.strip() for k, v in row.items()}
        timetable_df.append(cleaned_row)

print("=" * 70)
print("RECOMMENDATION ENGINE - DATA LOADING")
print("=" * 70)
print(f"Student Survey: {len(student_survey)} rows")
print(f"Classroom Observation: {len(classroom_observation)} rows")
print(f"Classroom Master: {len(classroom_master)} rows")
print(f"Timetable: {len(timetable_df)} rows")

# ----------------------------------------------------
# 2. SCORING FUNCTIONS
# ----------------------------------------------------
def calculate_attendance_score(attendance_percentage):
    if attendance_percentage >= 85:
        return 40
    elif attendance_percentage >= 75:
        return 32
    elif attendance_percentage >= 65:
        return 24
    elif attendance_percentage >= 50:
        return 16
    else:
        return 8

# Preference Score
preference_column = "Which lecture timing do you find most comfortable?"
preference_counts = Counter(r[preference_column].strip() for r in student_survey if r.get(preference_column))
maximum_preference_count = max(preference_counts.values())

def calculate_preference_score(response_count):
    return round((response_count / maximum_preference_count) * 25, 2)

preference_scores = {timing: calculate_preference_score(count) for timing, count in preference_counts.items()}

# Concentration Score
concentration_column = "Does the timing of a lecture affect your concentration?"
concentration_counts = Counter(r[concentration_column].strip() for r in student_survey if r.get(concentration_column))
impact_values = {"Never": 0, "Rarely": 25, "Sometimes": 50, "Often": 75, "Very Often": 100}
weighted_impact = sum(impact_values.get(resp, 0) * count for resp, count in concentration_counts.items())
average_impact = weighted_impact / sum(concentration_counts.values())
concentration_score = round((1 - (average_impact / 100)) * 15, 2)

# Schedule Score
continuous_column = "How often do you have 3 or more lectures continuously?"
gaps_column = "How often do you have long gaps between lectures?"
continuous_counts = Counter(r[continuous_column].strip() for r in student_survey if r.get(continuous_column))
gaps_counts = Counter(r[gaps_column].strip() for r in student_survey if r.get(gaps_column))
schedule_frequency_values = {"Never": 0, "Occasionally": 25, "Sometimes": 50, "Often": 75, "Always": 100}

def calculate_schedule_burden(counts):
    weighted_burden = sum(schedule_frequency_values.get(r, 0) * c for r, c in counts.items())
    return weighted_burden / sum(counts.values())

continuous_burden = calculate_schedule_burden(continuous_counts)
gaps_burden = calculate_schedule_burden(gaps_counts)
continuous_score = round((1 - (continuous_burden / 100)) * 5, 2)
gaps_score = round((1 - (gaps_burden / 100)) * 5, 2)
schedule_score = round(continuous_score + gaps_score, 2)

# On-Time Score
valid_start = [r["Started_On_Time"].strip() for r in classroom_observation if r.get("Started_On_Time") in ["Yes", "No"]]
valid_end = [r["Ended_On_Time"].strip() for r in classroom_observation if r.get("Ended_On_Time") in ["Yes", "No"]]
start_on_time_rate = (valid_start.count("Yes") / len(valid_start)) * 100
end_on_time_rate = (valid_end.count("Yes") / len(valid_end)) * 100
start_score = round((start_on_time_rate / 100) * 5, 2)
end_score = round((end_on_time_rate / 100) * 5, 2)
on_time_score = round(start_score + end_score, 2)

# Slot Attendance Scores
slot_att_lists = defaultdict(list)
for obs in classroom_observation:
    slot_att_lists[obs["Time_Slot"]].append(obs["Attendance_Percentage"])

slot_attendance_scores = {}
slot_avg_attendance = {}
for ts, att_list in slot_att_lists.items():
    avg_att = sum(att_list) / len(att_list)
    slot_avg_attendance[ts] = round(avg_att, 2)
    slot_attendance_scores[ts] = calculate_attendance_score(avg_att)

# Global Scores
global_concentration_score = concentration_score
global_schedule_score = schedule_score
global_on_time_score = on_time_score

all_time_slots = [
    "1:00-1:40", "1:40-2:20", "2:20-3:00", "3:30-4:10",
    "4:10-4:50", "4:50-5:30", "5:30-6:10", "6:10-6:50"
]

slot_score_dict = {}
for ts in all_time_slots:
    att_score = slot_attendance_scores.get(ts, 0)
    pref_score = preference_scores.get(ts, 0.0)
    total_score = round(att_score + pref_score + global_concentration_score + global_schedule_score + global_on_time_score, 2)
    slot_score_dict[ts] = {
        "Time_Slot": ts,
        "Attendance_Score": att_score,
        "Preference_Score": pref_score,
        "Concentration_Score": global_concentration_score,
        "Schedule_Score": global_schedule_score,
        "On_Time_Score": global_on_time_score,
        "Total_Score": total_score,
        "Average_Attendance": slot_avg_attendance.get(ts, 0),
        "Preference_Responses": preference_counts.get(ts, 0),
        "Is_Problem": total_score < 60
    }

print("\n" + "=" * 70)
print("BASE LECTURE SLOT EFFICIENCY SCORES")
print("=" * 70)
for ts, data in slot_score_dict.items():
    print(f"{ts}: Att={data['Attendance_Score']} Pref={data['Preference_Score']} Conc={data['Concentration_Score']} Sched={data['Schedule_Score']} OnTime={data['On_Time_Score']} -> Total={data['Total_Score']} (Problem: {data['Is_Problem']})")

# ----------------------------------------------------
# 3. PROBLEM DETECTION & LECTURES
# ----------------------------------------------------
problem_slot_names = [ts for ts, d in slot_score_dict.items() if d["Total_Score"] < 60]

problem_lectures = [
    row for row in timetable_df
    if row["Time_Slot"] in problem_slot_names
    and row["Session_Type"] == "Lecture"
    and row["Subject"] != "FREE"
]

print("\n" + "=" * 70)
print(f"PROBLEM LECTURES: {len(problem_lectures)}")
print("=" * 70)

# ----------------------------------------------------
# 4. BETTER AVAILABLE ALTERNATIVE SLOTS
# ----------------------------------------------------
alternative_slots = []
for lecture in problem_lectures:
    division = lecture["Division"]
    day = lecture["Day"]
    current_slot = lecture["Time_Slot"]

    if current_slot not in slot_score_dict:
        continue
    current_score = slot_score_dict[current_slot]["Total_Score"]

    used_slots_for_division = [
        r["Time_Slot"] for r in timetable_df
        if r["Division"] == division and r["Day"] == day and r["Session_Type"] == "Lecture"
    ]

    for alt_slot in all_time_slots:
        if alt_slot == current_slot:
            continue
        if alt_slot in used_slots_for_division:
            continue
        if alt_slot not in slot_score_dict:
            continue
        alt_score = slot_score_dict[alt_slot]["Total_Score"]
        if alt_score <= current_score:
            continue

        alternative_slots.append({
            "Day": day,
            "Division": division,
            "Subject": lecture["Subject"],
            "Classroom": lecture["Classroom"],
            "Current_Slot": current_slot,
            "Current_Score": round(current_score, 2),
            "Alternative_Slot": alt_slot,
            "Alternative_Score": round(alt_score, 2),
            "Score_Improvement": round(alt_score - current_score, 2)
        })

print(f"Total Better Available Alternatives Found: {len(alternative_slots)}")

# ----------------------------------------------------
# 5. CLASSROOM UTILIZATION & ESTIMATES
# ----------------------------------------------------
classroom_obs_map = defaultdict(list)
for o in classroom_observation:
    classroom_obs_map[o["Classroom"]].append(o["Students_Present"])

classroom_master_dict = {c["Classroom"]: c for c in classroom_master}

classroom_utilization = []
for c_name, c_info in sorted(classroom_master_dict.items()):
    students = classroom_obs_map.get(c_name, [])
    avg_students = round(sum(students) / len(students), 2) if students else 0
    obs_count = len(students)
    cap = c_info["Capacity"]
    util_pct = round((avg_students / cap) * 100, 2) if cap > 0 else 0
    classroom_utilization.append({
        "Classroom": c_name,
        "Capacity": cap,
        "Average_Students": avg_students,
        "Observations": obs_count,
        "Utilization_Percentage": util_pct
    })

division_student_map = defaultdict(list)
for o in classroom_observation:
    if o.get("Division") and o["Division"] != "N/A":
        division_student_map[o["Division"]].append(o["Students_Present"])

division_student_estimates = {
    div: round(sum(s_list) / len(s_list), 2) for div, s_list in division_student_map.items()
}
print("Division Student Estimates:", division_student_estimates)

# ----------------------------------------------------
# 6. CONFLICT-FREE RECOMMENDATIONS
# ----------------------------------------------------
used_recommended_slots = defaultdict(set)
reserved_classrooms = defaultdict(set)
conflict_free_recommendations = []

# Group candidates by Day, Division, Subject, Current_Slot
grouped_candidates = defaultdict(list)
# Sort candidates as in recommendation_engine.py: Day, Division, Subject, Current_Slot, Alternative_Score desc
sorted_candidates = sorted(
    alternative_slots,
    key=lambda x: (x["Day"], x["Division"], x["Subject"], x["Current_Slot"], -x["Alternative_Score"])
)

for c in sorted_candidates:
    key = (c["Day"], c["Division"], c["Subject"], c["Current_Slot"])
    grouped_candidates[key].append(c)

for (day, division, subject, current_slot), cand_list in grouped_candidates.items():
    first_candidate = cand_list[0]
    current_classroom = first_candidate["Classroom"]
    current_score = first_candidate["Current_Score"]
    division_day_key = (day, division)

    # Try best alternative first
    cand_list_sorted = sorted(cand_list, key=lambda x: -x["Alternative_Score"])
    for candidate in cand_list_sorted:
        alt_slot = candidate["Alternative_Slot"]
        alt_score = candidate["Alternative_Score"]

        # Check division conflict
        if alt_slot in used_recommended_slots[division_day_key]:
            continue

        # Find classrooms occupied in original timetable at (day, alt_slot)
        occupied_rooms = set(
            r["Classroom"] for r in timetable_df
            if r["Day"] == day and r["Time_Slot"] == alt_slot and r["Session_Type"] == "Lecture" and r.get("Classroom") and r["Classroom"] != "N/A"
        )

        # Classrooms already reserved by earlier recommendation
        classroom_key = (day, alt_slot)
        occupied_rooms.update(reserved_classrooms[classroom_key])

        # Available rooms from classroom_master
        available_rooms = [c for c in classroom_master if c["Classroom"] not in occupied_rooms]
        if not available_rooms:
            continue

        estimated_students = division_student_estimates.get(division)
        if estimated_students is None:
            continue

        suitable_rooms = [c for c in available_rooms if c["Capacity"] >= estimated_students]
        if not suitable_rooms:
            continue

        suitable_room_names = [c["Classroom"] for c in suitable_rooms]
        if current_classroom in suitable_room_names:
            rec_classroom = current_classroom
        else:
            rec_classroom = suitable_room_names[0]

        used_recommended_slots[division_day_key].add(alt_slot)
        reserved_classrooms[classroom_key].add(rec_classroom)

        conflict_free_recommendations.append({
            "Day": day,
            "Division": division,
            "Subject": subject,
            "Current_Slot": current_slot,
            "Recommended_Slot": alt_slot,
            "Current_Classroom": current_classroom,
            "Recommended_Classroom": rec_classroom,
            "Current_Score": current_score,
            "Recommended_Score": alt_score,
            "Score_Improvement": round(alt_score - current_score, 2)
        })
        break

print(f"\nTotal Conflict-Free Recommendations: {len(conflict_free_recommendations)}")
for rec in conflict_free_recommendations:
    print(f"  [{rec['Day']} - Div {rec['Division']}]: {rec['Subject']} | {rec['Current_Slot']} ({rec['Current_Score']}) -> {rec['Recommended_Slot']} ({rec['Recommended_Score']}) [+{rec['Score_Improvement']}] | Room: {rec['Current_Classroom']} -> {rec['Recommended_Classroom']}")
