import json
import csv
from collections import Counter, defaultdict

# Load all 4 datasets
with open('cleaned_classroom_master_data.csv', encoding='utf-8') as f:
    classrooms = list(csv.DictReader(f))
    for c in classrooms:
        c['Capacity'] = int(c['Capacity'])
        c['Minimum_Suitable_Class_Size'] = int(c.get('Minimum_Suitable_Class_Size', 0) or 0)
        c['Maximum_Suitable_Class_Size'] = int(c.get('Maximum_Suitable_Class_Size', 0) or 0)
        c['Building_Wing'] = c['Classroom'][0]
        fl_num = c['Classroom'][1]
        c['Floor'] = f"{fl_num}st" if fl_num == '1' else (f"{fl_num}nd" if fl_num == '2' else f"{fl_num}rd")

with open('cleaned_student_survey.csv', encoding='utf-8') as f:
    survey = list(csv.DictReader(f))

with open('cleaned_classroom_observation.csv', encoding='utf-8') as f:
    observations = list(csv.DictReader(f))
    for o in observations:
        o['Students_Present'] = float(o['Students_Present'])
        o['Attendance_Percentage'] = float(o['Attendance_Percentage'])
        o['Time_Slot'] = o['Time_Slot'].strip()

with open('cleaned_combined_timetable_data.csv', encoding='utf-8') as f:
    timetable = []
    for r in csv.DictReader(f):
        if r.get('Day') and r.get('Time_Slot'):
            timetable.append({k: v.strip() for k, v in r.items()})

# Import engine calculations
import recommendation_engine as eng

# Compute classroom observation stats
room_obs_stats = {}
for c in classrooms:
    c_name = c['Classroom']
    room_obs = [o for o in observations if o['Classroom'] == c_name]
    students = [o['Students_Present'] for o in room_obs]
    avg_students = round(sum(students) / len(students), 2) if students else 0
    util_pct = round((avg_students / c['Capacity']) * 100, 2) if c['Capacity'] > 0 else 0
    
    # Status
    # Categorize status:
    # Overcrowded if > 90% or observed overcrowded
    # Optimal if 55-90%
    # Underutilized if < 55%
    # Vacant if 0
    status_counts = Counter(o['Utilization_Status'] for o in room_obs)
    most_common_status = status_counts.most_common(1)[0][0] if status_counts else 'Optimal'
    
    # Issues detected in observations
    issues = {
        'ac_issues': sum(1 for o in room_obs if o.get('AC_Temperature_Issue') == 'Yes' or o.get('AC_Temperature_Issue_Binary') == '1'),
        'fan_issues': sum(1 for o in room_obs if o.get('Fan_Ventilation_Issue') == 'Yes' or o.get('Fan_Ventilation_Issue_Binary') == '1'),
        'lighting_issues': sum(1 for o in room_obs if o.get('Lighting_Issue') == 'Yes' or o.get('Lighting_Issue_Binary') == '1'),
        'seating_issues': sum(1 for o in room_obs if o.get('Seating_Issue') == 'Yes' or o.get('Seating_Issue_Binary') == '1'),
        'noise_issues': sum(1 for o in room_obs if o.get('Noise_Issue') == 'Yes' or o.get('Noise_Issue_Binary') == '1'),
        'other_issues': [o['Other_Issue'] for o in room_obs if o.get('Other_Issue') and o['Other_Issue'] not in ['No other issue', '']]
    }
    
    room_obs_stats[c_name] = {
        'classroom': c_name,
        'capacity': c['Capacity'],
        'room_type': c['Room_Type'],
        'ac_available': c['AC_Available'],
        'projector_available': c['Projector_Available'],
        'whiteboard_available': c['Whiteboard_Available'],
        'room_size_category': c['Room_Size_Category'],
        'average_students': avg_students,
        'observations_count': len(room_obs),
        'utilization_percentage': util_pct,
        'utilization_status': most_common_status,
        'status_counts': dict(status_counts),
        'issues': issues
    }

# Also gather student survey insights
survey_insights = {
    'total_responses': len(survey),
    'concentration_score': eng.global_concentration_score,
    'schedule_score': eng.global_schedule_score,
    'on_time_score': eng.global_on_time_score,
    'comfortable_timings': dict(eng.preference_counts),
    'concentration_counts': dict(eng.concentration_counts),
    'continuous_counts': dict(eng.continuous_counts),
    'gaps_counts': dict(eng.gaps_counts),
    'start_on_time_rate': round(eng.start_on_time_rate, 2),
    'end_on_time_rate': round(eng.end_on_time_rate, 2),
}

# Compile full dataset bundle
bundle = {
    'summary': {
        'total_lectures': len(timetable),
        'total_lecture_sessions': len([t for t in timetable if t['Session_Type'] == 'Lecture' and t['Subject'] != 'FREE']),
        'total_free_slots': len([t for t in timetable if t['Subject'] == 'FREE']),
        'total_classrooms': len(classrooms),
        'total_observations': len(observations),
        'total_survey_responses': len(survey),
        'total_problem_lectures': len(eng.problem_lectures),
        'total_alternatives_found': len(eng.alternative_slots),
        'total_recommendations': len(eng.conflict_free_recommendations),
        'average_slot_score': round(sum(d['Total_Score'] for d in eng.slot_score_dict.values()) / len(eng.slot_score_dict), 2)
    },
    'slot_scores': eng.slot_score_dict,
    'all_time_slots': eng.all_time_slots,
    'classrooms': classrooms,
    'classroom_stats': room_obs_stats,
    'division_student_estimates': eng.division_student_estimates,
    'recommendations': eng.conflict_free_recommendations,
    'alternative_slots': eng.alternative_slots,
    'survey_insights': survey_insights,
    'observations': observations,
    'timetable': timetable
}

with open('src/data/slotSenseData.json', 'w', encoding='utf-8') as f:
    json.dump(bundle, f, indent=2)

print("Generated src/data/slotSenseData.json successfully!")
